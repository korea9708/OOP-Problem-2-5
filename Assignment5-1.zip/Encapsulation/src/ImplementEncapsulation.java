public class ImplementEncapsulation {
	public static void main(String[] args) {
		// this class needs a main method!
		// we created two constructors, so we have two ways to instantiate
		// EncapsulationExample
		EncapsulationExample newExample = new EncapsulationExample();
		// we used the no argument constructor to create a new isntance of
		// EncapsulationExample

		EncapsulationExample newExample2 = new EncapsulationExample("Stanescu", 36);
		// we used the constructor that took two arguments

		//
		System.out.println(newExample.name + " is " + newExample.age + " years old!");
		System.out.println(newExample2.name + " is " + newExample2.age + " years old!");

		// normally we can't do this!
		newExample.name = "Some new name";
		// or this
		newExample.age = -1;

		// normally we can't do this!
		newExample2.name = "Some new name";
		// or this
		newExample2.age = -1;

		//
		System.out.println(newExample.name + " is " + newExample.age + " years old!");
		System.out.println(newExample2.name + " is " + newExample2.age + " years old!");

		/*
		 * Typically our instance variables are encapsulated so we can't access them...
		 * Because we didn't do this properly we now have public access!!! Let's fix it
		 * together now.
		 */
	}// end of main method
}// end of ImplementEncapsulation class