
public class EncapsulationExample {
	//this class doesn't have a main method
	//these are instance variables
	//each instance of an Object will have it's own instance of these variables
	// encapsulate instant variables by adding private
	private String name;
	private int age;
	private String gender;
	private int ruid;

	//getter method for gender
	public String getGender() 
	{
		return gender;
	}
	// setter method that changes gender to lower cases
	public void setGender(String gender)
	{
		this.gender=gender.toLowerCase();
	}
	//getter method for ruid
	public int getRUID() 
	{
		return ruid;
	}
	//setter method for ruid, however the ruid variable is primative and must be 9 digits so use if statement 
	public void setRUID(int ruid)  
	{
		if (ruid>99999999 && ruid<=999999999)ruid =this.ruid;
		
	}
		
	//these are constructors
	//these are how we will instanstiate a new EncapsulationExample
	public EncapsulationExample(){
		name = "Youngjun Kim";
		age = 22;
		gender= "male";
		ruid = 171004332;
	}//this constructor takes no arguments
	
	//this constructor will take arguments
	public EncapsulationExample(String name, String gender, int age, int ruid){
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.ruid = ruid;
	}//this contstructor took a String and an int as an argument
}//end of EncapsulationExample class